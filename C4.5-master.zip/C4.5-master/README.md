# C4.5
an implementation of the C4.5 algorithm in Java

---

This is a basic example of the C4.5 decision tree algorithm developed by Ross Quinlan.
C4.5 is generally used for classification and is oftern referred to as a statistical classifier.


### Links

- http://www.rulequest.com/Personal/
- https://en.wikipedia.org/wiki/C4.5_algorithm
